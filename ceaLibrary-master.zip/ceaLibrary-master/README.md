ceaLibrary
==========

Qom University Of TEchnology Computer Engeenring Assosiation Member Managment CLI Application ,

this app do below operation for CEA:
        "1) Insert Student"
        "2) Delete Student"
        "3) Modify Student"
        "4) List SignIn Student"
        
this app use SQlite DB for saving Data,
this app use SHELLScript for app itSelf

