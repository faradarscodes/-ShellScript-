linkgrabber
===========
this is a shellScript and it's porpose is grab the link that user copy to the clipBoard
and check the link,,if this is lead to the specific file,,show the dialog to the user & 
get the destination address for saving file and start downloading,
